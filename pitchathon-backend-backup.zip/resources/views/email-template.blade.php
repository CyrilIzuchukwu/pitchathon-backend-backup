

<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
    <h1>{{ $data }}</h1>
    <!--<p>{{ $body }}</p>-->
     
    <p>Thank you</p>
</body>
</html>
