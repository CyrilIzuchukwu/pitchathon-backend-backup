<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\VerifiesEmails;
use Illuminate\Support\Facades\Auth;
class VerificationController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Email Verification Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling email verification for any
    | user that recently registered with the application. Emails may also
    | be re-sent if the user didn't receive the original email message.
    |
    */

    use VerifiesEmails;

    /**
     * Where to redirect users after verification.
     *
     * @var string
     */
    // protected $redirectTo = RouteServiceProvider::HOME;
    
        protected function redirectTo()
    {
        if(Auth::user()->role_as == '1') //1 = Admin Login
        {
            // return redirect('admin/dashboard')->with('message','WELCOME TO YOUR DASHBOARD');
            return 'admin/dashboard';
        }
        elseif(Auth::user()->role_as == '2')// sub admin
        {
             return redirect('Sub_admin/dashboard')->with('message','WELCOME TO YOUR Sub_DASHBOARD');
        }
                        elseif(Auth::user()->role_as == '3')// sub admin
        {
             return redirect('Jury/dashboard')->with('message','WELCOME TO YOUR Jury_DASHBOARD');
        }
                elseif(Auth::user()->role_as == '4')// sub admin
        {
             return redirect('Review/dashboard')->with('message','WELCOME TO YOUR Review_DASHBOARD');
        }
        elseif(Auth::user()->role_as == '0') // Normal or Default User Login
        {
            return '/home';
        }
    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('signed')->only('verify');
        $this->middleware('throttle:6,1')->only('verify', 'resend');
    }
}
