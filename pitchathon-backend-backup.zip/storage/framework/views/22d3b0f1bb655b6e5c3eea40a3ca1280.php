<?php $__env->startSection('content'); ?>
                <!-- Main section  -->
<section
    class="lg:col-span-5 w-full lg:w-auto flex flex-col items-start lg:p-0 py-4 px-4 gap-8 lg:mb-8 mb-4">
    <!-- Notifications -->

    <div class="my-2 w-full flex flex-col lg:pr-8 pr-4 pl-4">
        <h1 class="text-center font-bold lg:text-xl text-base mt-4 text-primary">Notifications</h1>

        <div class="border-b border-primary my-3"></div>
<?php if(count(auth()->user()->notifications) > 0): ?>

    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w-full">
            <div class="flex justify-between items-center my-6">
                <h2 class="lg:text-lg text-base font-medium text-primary">Notification <?php echo e($loop->index + 1); ?></h2>
    
                <button
                    class="bg-primary flex items-center hover:bg-secondary p-1 md:p-3 md:w-auto text-white rounded <?php if(!$notification->read_at): ?> unread <?php endif; ?>" onclick="location.href='<?php echo e(route('home', $notification->id)); ?>'">
                    <i class="ri-check-double-fill pr-4"></i>   Mark as read
                </button>
    
            </div>
            <p class="text-justify text-primary font-light">
                <?php echo e($notification->message); ?>

            </p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

<?php else: ?>
    <div class="w-full">
        <div class="flex justify-between items-center my-6">
            <h2 class="lg:text-lg text-base font-medium text-primary">No Notifications Available</h2>
        </div>
        <p class="text-justify text-primary font-light">
           Check Later
        </p>
    </div>
<?php endif; ?>

    </div>


</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MY LAPTOP\Documents\laravel\pitchathon-backend-backup\resources\views/applicant-notification.blade.php ENDPATH**/ ?>