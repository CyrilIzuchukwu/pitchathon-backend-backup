<?php $__env->startSection('title'); ?>
Welcome admin
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>




<!-- Main section  -->
<section class="lg:col-span-5 w-full lg:w-auto flex flex-col items-start pl-3 lg:pr-8 pr-3  gap-8">
    <!-- List of submitted solution -->
    <!-- Reviews   -->
    <main class="w-full grid lg:grid-cols-1 md:grid-cols-1 gap-3
                                        mb-10
                                        lg:pt-8 lg:pr-8 md:pr-2 pr-1" data-aos="fade-up" data-aos-duration="1000">




        <!-- Login form  -->

        <div class="md:mt-20 mt-0">
            <div class="w-full  items-center
                justify-center">
                <form class="max-w-lg mx-auto xs:mt-20 w-3/4 mb-6 max-h-full" method="POST" action="<?php echo e(url('adminregister')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="justify-center mt-6">
                        <h3 class="text-center md:text-3xl capitalize text-xl text-primary font-medium mt-10 md:mt-0">
                            Create Reviewers and Jury
                        </h3>
                    </div>
                    <?php if($errors->any()): ?>
                    <div class="text-red-500" id="demo">
                        <button class="float-right" onclick="myFunction()">X</button>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                    <script>
                        function myFunction() {
                            const element = document.getElementById("demo");
                            element.remove();
                        }
                    </script>
                    <div class="mt-6">
                        <div class="w-full gap-3 flex justify-around">
                            <div class="w-full flex items-center">
                                <input type="text" placeholder="Name" id="firstName" required name="name" oninput="validateForm()" class="w-full border rounded px-3 py-2 text-gray-700 focus:outline" />

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span id="firstNameError" class="text-xs text-red-500">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="w-full flex items-center">
                                <input type="email" placeholder="Email Address" id="email" required name="email" oninput="validateForm()" class="w-full border rounded px-3 py-2 focus:outline text-gray-700 " />

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span id="emailError" class="text-xs text-red-500">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="w-full mt-6">
                            <label class="block text-primary mb-2 ml-3 ">Role</label>
                            <select onchange="toggleOtherInputx(this)" name="role_as" class="shadow border-none rounded-md w-full py-3 px-3 bg-gray-100 leading-tight focus:outline focus:outline-primary">
                                <option value="">Select</option>
                                <option value="4">Reviewer</option>
                                <option value="3">Jury</option>
                            </select>
                            <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-red-500">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="w-full mt-6">
                            <div class="flex items-center relative">
                                <input id="password" type="password" placeholder="Password" id="password" name="password" oninput="validateForm()" class="w-full border rounded px-3 py-2 text-gray-700 focus:outline" name="password" required autocomplete="new-password">
                                <div style="margin-left: -55px;" class="right-4 text-primary text-xl top-2.5 cursor-pointer" id="pswdEye1">
                                    <i class="ph-light ph-eye-closed"></i>
                                    <i class="ph-light ph-eye" style="display: none;"></i>
                                </div>
                            </div>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="passwordError" class="text-xs text-red-500">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="w-full mt-6">
                            <div class="flex items-center relative">
                                <input id="confirmPassword" type="password" placeholder="Confirm Password" id="confirmPassword" oninput="validateForm()" class="w-full border rounded px-3
                                            py-2
                                            text-gray-700 focus:outline" name="password_confirmation" required autocomplete="new-password">
                                <div style="margin-left: -55px;" class="right-4 text-primary text-xl top-2.5 cursor-pointer" id="pswdEye2">
                                    <i class="ph-light ph-eye-closed"></i>
                                    <i class="ph-light ph-eye" style="display: none;"></i>
                                </div>
                            </div>

                        </div>

                        <br />
                        <button type="submit" value="Submit" class="w-full py-2 mt-8 rounded text-white
                                            text-gray-100
                                            focus:outline-dashed
                                            bg-primary

                                            hover:bg-secondary
                                            hover:text-white">
                            Register
                        </button>


                    </div>

                </form>
                <script>
                    // Show & Hide Password
                    const passwordEye1 = document.getElementById("pswdEye1"),
                        passwordEye2 = document.getElementById("pswdEye2"),
                        password = document.getElementById("password"),
                        confirmPassword = document.getElementById("confirmPassword");

                    //icons
                    const iconClose1 = passwordEye1.querySelector(".ph-eye-closed"),
                        iconOpen1 = passwordEye1.querySelector(".ph-eye"),
                        iconClose2 = passwordEye2.querySelector(".ph-eye-closed"),
                        iconOpen2 = passwordEye2.querySelector(".ph-eye");

                    //for Password
                    passwordEye1.addEventListener("click", () => {
                        if (password.type === "password") {
                            password.type = "text";
                            iconClose1.style.display = "none";
                            iconOpen1.style.display = "inline-block";
                        } else if (password.type === "text") {
                            password.type = "password";
                            iconClose1.style.display = "inline-block";
                            iconOpen1.style.display = "none";
                        }
                    });
                    //
                    passwordEye2.addEventListener("click", () => {
                        if (confirmPassword.type === "password") {
                            confirmPassword.type = "text";
                            iconClose2.style.display = "none";
                            iconOpen2.style.display = "inline-block";
                        } else if (confirmPassword.type === "text") {
                            confirmPassword.type = "password";
                            iconClose2.style.display = "inline-block";
                            iconOpen2.style.display = "none";
                        }
                    });
                </script>
            </div>

        </div>

        <!-- Reviewer Profile-->

        <div class=" mt-10 gap-6 flex-col flex ">
            <h1 class="text-gradient md:text-xl text-base font-medium">Reviewers</h1>
            <?php $__empty_1 = true; $__currentLoopData = $btc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="flex items-center justify-start gap-6">
                <div class="flex md:flex-row flex-col
                                                    items-start
                                                    md:items-center
                                                    md:justify-center gap-3 ">

                    <p class="text-base text-primary">


                        <?php if(isset($item->review->name)): ?>
                        <?php echo e($item->review->name); ?>

                        <?php else: ?>
                        This reviewer has been deleted
                        <?php endif; ?>
                    </p>

                    <?php if(isset($item->review->id)): ?>


                    <div class="flex items-center
                                                        justify-center gap-3">

                        <a href="<?php echo e(url('userManagements/' . $item->review->id)); ?>" class="px-3 bg-primary p-1 text-white
                                                            rounded">Reviewed
                            Solutions</a>
                        <?php if($item->review->status == 1): ?> 
                        <a onclick="checker1()" href="<?php echo e(route('users.update.status',['user_id' => $item->review->id,'status'=> 0 ])); ?>"><i class="ph ph-eye text-xl"></i></a>
                        <script>
                            function checker1() {
                                var result = confirm('Are you sure you want to restrict this Reviewer?');
                                if (result == false) {
                                    event.preventDefault();
                                }
                            }
                        </script>
                        <?php else: ?> 
                        <a onclick="checker11()" href="<?php echo e(route('users.update.status',['user_id' => $item->review->id,'status'=> 1 ])); ?>"><i class="ph ph-eye-slash text-xl"></i></a>
                        <script>
                            function checker11() {
                                var result = confirm('Are you sure you want to enable this Reviewer');
                                if (result == false) {
                                    event.preventDefault();
                                }
                            }
                        </script>
                        <?php endif; ?>

                        <!--<a onclick="checker()" href ="<?php echo e(url('admin/delete-reviewer/'. $item->review->id)); ?>"><i class="ph ph-trash text-secondary text-xl"></i></a>-->
                        <a onclick="checker()" href="<?php echo e(route('users.update.deleted_at',['user_id' => $item->review->id,'deleted_at'=> 'delete' ])); ?>"><i class="ph ph-trash text-secondary text-xl"></i></a>
                    </div>

                    <?php else: ?>

                    <a onclick="checker11111()" href="<?php echo e(url('admin/restore')); ?>"><i class="ph ph-clock-clockwise text-xl"></i></a>
                    <?php endif; ?>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7">No Reviewers yet</td>
            </tr>
            <?php endif; ?>


            <?php echo e($btc->links('pagination::tailwind')); ?>

        </div>



        <!-- Juries  -->



        <div class=" mt-20 gap-6 flex-col flex md:w-10/12
                                            w-full">
            <h1 class="text-secondary text-xl
                                                font-bold">Juries</h1>
            <?php $__empty_1 = true; $__currentLoopData = $btcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="flex items-center justify-start gap-6">
                <div class="flex md:flex-row flex-col
                                                    items-start
                                                    md:items-center
                                                    md:justify-center gap-3 ">

                    <p class="text-base text-primary"> <?php if(isset($item->review->name)): ?>
                        <?php echo e($item->review->name); ?>

                        <?php else: ?>
                        This Jury has been deleted
                        <?php endif; ?>
                    </p>
                    <?php if(isset($item->review->id)): ?>
                    <div class="flex items-center
                                                        justify-center gap-3">

                        <a href="<?php echo e(url('userManagementss/' . $item->review->id)); ?>" class="px-3 bg-primary p-1 text-white
                                                            rounded">Reviewed
                            Solutions</a>

                        <?php if($item->review->status1 == 1): ?> 

                        <a onclick="checker1111111()" href="<?php echo e(route('users.updates.status',['user_id' => $item->review->id,'status1'=> 0 ])); ?>"><i class="ph ph-eye text-xl"></i></a>
                        <?php else: ?> 
                        <a onclick="checker11111111()" href="<?php echo e(route('users.updates.status',['user_id' => $item->review->id,'status1'=> 1 ])); ?>"><i class="ph ph-eye-slash text-xl"></i></a>
                        <?php endif; ?>
                        <!--<a onclick="checker111()" href ="#"><i class="ph ph-trash text-secondary text-xl"></i></a>-->
                        <a onclick="checker()" href="<?php echo e(route('users.update.deleted_at',['user_id' => $item->review->id,'deleted_at'=> 'delete' ])); ?>"><i class="ph ph-trash text-secondary text-xl"></i></a>

                    </div>
                    <?php else: ?>

                    <a onclick="checker11111()" href="<?php echo e(url('admin/restore')); ?>"><i class="ph ph-clock-clockwise text-xl"></i></a>
                    <?php endif; ?>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7">No Jury yet</td>
            </tr>
            <?php endif; ?>
            <?php echo e($btcs->links('pagination::tailwind')); ?>

        </div>

    </main>
</section>
<script>
    function checker() {
        var result = confirm('Are you sure you want to delete this Reviewer');
        if (result == false) {
            event.preventDefault();
        }
    }
</script>
<script>
    function checker111() {
        var result = confirm('Are you sure you want to delete this Jury');
        if (result == false) {
            event.preventDefault();
        }
    }
</script>
<script>
    function checker11111() {
        var result = confirm('Are you sure you want to view the trashed');
        if (result == false) {
            event.preventDefault();
        }
    }
</script>
<script>
    function checker1111111() {
        var result = confirm('Are you sure you want to disable this Jury');
        if (result == false) {
            event.preventDefault();
        }
    }
</script>
<script>
    function checker11111111() {
        var result = confirm('Are you sure you want to enable this Jury');
        if (result == false) {
            event.preventDefault();
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MY LAPTOP\Documents\laravel\pitchathon-backend-backup\resources\views/admin/userManagement.blade.php ENDPATH**/ ?>