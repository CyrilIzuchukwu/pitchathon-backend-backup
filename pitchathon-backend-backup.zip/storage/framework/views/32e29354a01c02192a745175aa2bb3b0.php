<?php $__env->startSection('title'); ?>
Welcome admin
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- Main section  -->
<section class="lg:col-span-5 w-full lg:w-auto flex flex-col items-start pl-3 lg:pr-8 pr-3  gap-8">
    <!-- List of submitted solution -->
    <main class="w-full flex flex-col gap-3 lg:my-8 my-4 lg:pr-8 md:pr-2 pr-1" data-aos="fade-up" data-aos-duration="1000">


        <h1 class=" lg:text-2xl text-xl text-center font-medium text-primary" data-aos="fade-up" data-aos-duration="1000">Production/Manufacturing<span class="text-gradient"> Solutions</span>
        </h1>


        <ul class="pagination" style="display:flex; justify-content:start; align-items:center; gap:20px">
            <!-- Previous Page Link -->
            <?php if($btc->onFirstPage()): ?>
            <li class="disabled"><span>&laquo;</span></li>
            <?php else: ?>
            <li><a href="<?php echo e($btc->previousPageUrl()); ?>" class="prev bg-primary text-white" rel="prev"> Previous &laquo; <?php echo e($btc->currentPage() - 1); ?></a></li>
            <?php endif; ?>

            <!-- Pagination Elements -->
            <?php $__currentLoopData = $btc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item['url']): ?>
            <?php
            $pageNumber = (int) str_replace(url()->current().'?page=', '', $item['url']);
            ?>
            <li class="<?php echo e($page == $pageNumber ? 'active' : ''); ?>">
                <a href="<?php echo e($item['url']); ?>"><?php echo e($pageNumber); ?></a>
            </li>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <span class="cp bg-secondary"><?php echo e($btc->currentPage()); ?></span>

            <!-- Next Page Link -->
            <?php if($btc->hasMorePages()): ?>
            <li><a href="<?php echo e($btc->nextPageUrl()); ?>" class="next bg-primary text-white" rel="next"><?php echo e($btc->currentPage() + 1); ?> &raquo; Next</a></li>
            <?php else: ?>
            <li class="disabled"><span>&raquo;</span></li>
            <?php endif; ?>
        </ul>




        <style>
            .prev,
            .next {
                border: none;
                padding: 6px 20px;
                border-radius: 5px;
                transition: 0.7s;

            }

            .cp {
                border: none;
                border-radius: 50%;
                height: 40px;
                width: 40px;
                color: #fff;
                text-align: center;
                line-height: 39px;
            }
        </style>


        <?php $__empty_1 = true; $__currentLoopData = $btc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <section class="w-full flex flex-col gap-3 py-5 px-5 rounded-md mt-3 bg-slate-100">
            <div class="w-full flex flex-row items-center md:gap-3" data-aos="fade-up" data-aos-duration="1000">
                <!-- User Info  -->
                <div class="flex flex-wrap items-center gap-3">
                    <h3 class="lg:text-lg md:text-base text-sm text-primary font-medium font-poppin flex items-center lg:gap-2 gap-1">
                        <?php echo e($item->user->name); ?> <i class="ph-light ph-seal-check"></i>
                    </h3>
                    <h4 class="text-secondary text-sm md:text-base bg-secondary/20 lg:px-5 px-3 rounded py-1.5">
                        <?php echo e(ucfirst($item->target_sector)); ?>

                    </h4>

                    <a href="<?php echo e(url('productions/' . $item->id)); ?>" class="text-white text-sm md:text-base bg-primary lg:px-5 px-3 rounded py-1.5 flex items-center">View
                        Solution</a>
                </div>
            </div>
            <!-- About text for user  -->
            <p class="text-base text-primary w-full font-poppin font-light text-justify" data-aos="fade-up" data-aos-duration="1000">My name is <?php echo e($item->user->name); ?>, and my
                company is called
                <?php echo e($item->name_of_business); ?>.
                <hr />About my business is <?php echo e($item->description); ?>.
            </p>
        </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="7">No Applicant_form Avaliable</td>
        </tr>
        <?php endif; ?>

    </main>


</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MY LAPTOP\Documents\laravel\pitchathon-backend-backup\resources\views/admin/production.blade.php ENDPATH**/ ?>