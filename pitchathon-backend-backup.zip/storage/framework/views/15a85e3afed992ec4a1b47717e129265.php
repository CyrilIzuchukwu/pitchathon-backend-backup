<aside class="lg:col-span-1 h-screen fixed top-[5.3rem] w-48 lg:flex left-0 flex-col" id="sidenavbar">
                <div
                    class="overflow-y-auto pt-8 pb-5 pr-4 h-full flex flex-col justify-between items-start bg-white shadow-lg">
                    <ul class="font-poppin" id="navlinks">
                        <li>
                            <a href="<?php echo e(url('Jury/dashboard')); ?>"
                                class="flex items-center pl-6 pr-2 py-2 font-normal text-primary hover:text-white rounded-r-full hover:bg-primary transition-all duration-300 text-xl ">
                                <i class="ph-light ph-command"></i>
                                <span class="ml-2 text-base">Dashboard</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('Jury/setting')); ?>"
                                class="flex items-center pl-6 pr-2 py-2 font-normal text-primary hover:text-white rounded-r-full hover:bg-primary transition-all duration-300 text-xl ">
                                <i class="ph-light ph-user-switch"></i>
                                <span class="ml-2 text-base">Change password</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('Jury/notification')); ?>"
                                class="flex items-center pl-6 pr-2 py-2 font-normal text-primary hover:text-white rounded-r-full hover:bg-primary transition-all duration-300 text-xl ">
                                <i class="ph-light ph-bell"></i>
                                <span class="ml-2 text-base">Notification</span>
                            </a>
                        </li>
                    </ul>


                    <ul class="pb-28 font-poppin ">
                        <li>
                            <a href="<?php echo e(route('logout')); ?>"
                                class="flex items-center pl-6 pr-2 py-2 font-normal transition-all duration-300 text-xl" onclick="event.preventDefault();
                                   document.getElementById('logout-form').submit();">
                                <i class="ph-light ph-sign-out text-secondary"></i>
                                <span class="ml-2 text-base text-gradient">Logout</span>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                                
                                
                            </a>
                        </li>
                    </ul>
                </div>
            </aside><?php /**PATH C:\Users\MY LAPTOP\Documents\laravel\pitchathon-backend-backup\resources\views/layouts/inc/jury/sidebar.blade.php ENDPATH**/ ?>