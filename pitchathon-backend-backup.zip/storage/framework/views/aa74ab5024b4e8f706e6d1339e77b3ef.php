<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pitcthaton_Review</title>
    <link href="<?php echo e(asset('jury/css/styles.css')); ?>" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/animation.css')); ?>">
        <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>

<body>

    <!-- General wrapper  -->
    <div class="wrapper font-poppin">

        <!-- Top Navbar section  -->
        <!-- inc -->
         <?php echo $__env->make('layouts.inc.review.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <!-- inc -->
        <main class="w-full h-auto lg:grid lg:grid-cols-6 flex flex-col gap-8 mt-24">
            <!-- Side Navbar  -->
             <!-- inc -->
              <?php echo $__env->make('layouts.inc.review.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <!-- inc -->
 <!-- yield content -->
            <!-- Main section  -->
<?php echo $__env->yieldContent('content'); ?>
<!-- yield content -->

        </main>
         <!-- inc -->
        <footer class="w-full flex items-center justify-center py-4 bg-primary">
            <p class="text-center text-sm text-white">DTC Nigeria &copy; 2023. All Rights Reserved</p>
        </footer>
 <!-- inc -->




    </div>

<script src="<?php echo e(asset('jury/js/main.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.4/flowbite.min.js"></script>
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        const modal = document.getElementById('defaultModal');
        window.onload = () => {
            modal.style.display = "flex";
            document.body.style.overflow = "hidden";
        }
    </script>
    <script>
        AOS.init();
    </script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
    <?php if(session('message')): ?>
        <script>
            swal("Good job!", "<?php echo e(session('message')); ?>!", "success");
        </script>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <script>
            swal("Error!", "<?php echo e(session('error')); ?>!", "warning");
        </script>
    <?php endif; ?>
</body>

</html><?php /**PATH C:\Users\MY LAPTOP\Documents\laravel\pitchathon-backend-backup\resources\views/layouts/review.blade.php ENDPATH**/ ?>